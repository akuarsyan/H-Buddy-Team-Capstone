package com.capstone.h_buddy.utils

const val BASE_URL = "https://h-buddy-articles-jvtjfxo25q-et.a.run.app/"
const val TIMEOUT_TIME = 20L
const val WEB_CLIENT_ID = "4220805963-rpkkqod6dtr4129kidil2l028f15q2h8.apps.googleusercontent.com"