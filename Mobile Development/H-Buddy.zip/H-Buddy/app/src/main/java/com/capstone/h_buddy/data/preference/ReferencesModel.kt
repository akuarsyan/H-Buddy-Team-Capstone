package com.capstone.h_buddy.data.preference

data class ReferencesModel(
    val imageId: Int,
    val title: String
)
