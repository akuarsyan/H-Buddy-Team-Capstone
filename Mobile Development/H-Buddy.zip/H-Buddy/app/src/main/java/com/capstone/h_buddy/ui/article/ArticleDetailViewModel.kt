package com.capstone.h_buddy.ui.article

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ArticleDetailViewModel(): ViewModel() {

}