package com.capstone.h_buddy.data.preference

data class CarouselModel(
    val imageId: Int,
    val title: String
)
